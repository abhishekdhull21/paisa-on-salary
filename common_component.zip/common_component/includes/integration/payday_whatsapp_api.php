<?php

function payday_whatsapp_api($type_id = 0, $lead_id = 0, $request_array = array()) {

    $responseArray = array("status" => 0, "errors" => "");
    if (!empty($type_id)) {
        $responseArray = whatsapp_api_call($type_id, $lead_id, $request_array);
    } else {
        $responseArray["errors"] = "Type id is can not be blank.";
    }

    return $responseArray;
}

function whatsapp_api_call($templete_type_id, $lead_id = 0, $request_array = array()) {

    $response_array = array("status" => 0, "errors" => "");

    $apiStatusId = 0;
    $apiResponseJson = "";
    $apiRequestDateTime = date("Y-m-d H:i:s");
    $apiResponseDateTime = "";
    $apiResponseData = "";
    $errorMessage = "";
    $curlError = "";
    

    $hardcode_response = false;

    $debug = !empty($_REQUEST['bltest']) ? 1 : 0;

    $user_id = !empty($_SESSION['isUserSession']['user_id']) ? $_SESSION['isUserSession']['user_id'] : 0;

    $leadModelObj = new LeadModel();
    
    

    try {


    if (empty($lead_id)) {
        throw new Exception('Lead is black.');
    }

     $LeadDetails = $leadModelObj->getLeadFullDetails($lead_id);
     
    if ($LeadDetails['status'] != 1) {
        throw new Exception("Application details not found");
    }

    $app_data = !empty($LeadDetails['app_data']) ? $LeadDetails['app_data'] : "";


    if ($app_data['lead_status_id'] != 14 && $app_data['lead_status_id'] != 19) {
        
        echo 'Testing Lead Details'; die;
         
    } else{
        
    $first_name = !empty($app_data['first_name']) ? trim(strtoupper($app_data['first_name'])) : "";
    $middle_name = !empty($app_data['middle_name']) ? trim(strtoupper($app_data['middle_name'])) : "";
    $sur_name = !empty($app_data['sur_name']) ? trim(strtoupper($app_data['sur_name'])) : "";

    $repayment_amount = !empty($app_data['repayment_amount']) ? trim($app_data['repayment_amount']) : "###";
    $repayment_date = !empty($app_data['repayment_date']) ? trim(strtoupper($app_data['repayment_date'])) : "###";
    $loan_recommended = !empty($app_data['loan_recommended']) ? trim(strtoupper($app_data['loan_recommended'])) : "";
    $due_amount = $loan_recommended - $repayment_amount;
    $customer_full_name = $first_name . (!empty($middle_name) ? " " . $middle_name : "") . (!empty($sur_name) ? " " . $sur_name : "");
    $loan_no = !empty($app_data['loan_no']) ? trim($app_data['loan_no']) : "###";

    $mobile = !empty($app_data['mobile']) ? $app_data['mobile'] : "";
    
    $reference_no = !empty($app_data['lead_reference_no']) ? $app_data['lead_reference_no'] : "";

    $apiRequestDateTime = date("Y-m-d H:i:s");
    
   $curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://backend.api-wa.co/campaign/smartping/api',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => json_encode([
      "apiKey" => "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY2ZWU3ZDQ4YjJlNjRjMGI3ODU2NDJiMiIsIm5hbWUiOiIgS2FzYXIgQ3JlZGl0ICYgQ2FwaXRhbCBQcml2YXRlIExpbWl0ZWQiLCJhcHBOYW1lIjoiQWlTZW5zeSIsImNsaWVudElkIjoiNjZlZTdkNDdiMmU2NGMwYjc4NTY0MmFjIiwiYWN0aXZlUGxhbiI6IkJBU0lDX01PTlRITFkiLCJpYXQiOjE3Mjc0Njc4MDh9.8tF-WLsYsxQMU5qbU0_oj-NTP46uD-pR1Zqsu70znM0",
      "campaignName" => "Repayment_reminder",
      "destination" => "+91".$mobile,
      "userName" => "rohtash@salaryontime.com",
      "source" => "any",
      "templateParams" => [
         $customer_full_name,
         $repayment_amount,
         $repayment_date,
         $loan_no
      ],
      "attributes" => new stdClass()  // Empty object
  ]),
  CURLOPT_HTTPHEADER => array(
    'Content-Type: application/json',
    'Accept: application/json'
  ),
));

$response = curl_exec($curl);
print_R($response); die;

        if (curl_errno($curl)) { // CURL Error
            $curlError = curl_error($curl);
            curl_close($curl);
            throw new RuntimeException("Something went wrong. Please try after sometime. Error: $curlError");
        } else {
            curl_close($curl);
            $apiResponseData = json_decode($response, true);
           
    
            if (!empty($apiResponseData)) {
                if (!empty($apiResponseData['msgId'])) {
                    $apiStatusId = 1;
                } else if (!empty($apiResponseData['message'])) {
                    throw new ErrorException($apiResponseData['message']);
                } else {
                    throw new ErrorException("Some error occurred. Please try again.[2]");
                }
            } else {
                throw new ErrorException("Some error occurred. Please try again.[1]");
            }
         }
        }
    } catch (ErrorException $le) {
        $apiStatusId = 2;
        $errorMessage = $le->getMessage();
    } catch (RuntimeException $re) {
        $apiStatusId = 3;
        $errorMessage = $re->getMessage();
    } catch (Exception $e) {
        $apiStatusId = 4;
        $errorMessage = $e->getMessage();
    }

    $insertApiLog = array();
    $insertApiLog['whatsapp_provider'] = 1;
    $insertApiLog['whatsapp_type_id'] = $templete_type_id;
    $insertApiLog['whatsapp_mobile'] = $mobile;
    $insertApiLog['whatsapp_request'] = $json_request;
    $insertApiLog['whatsapp_response'] = $apiResponseJson;
    $insertApiLog['whatsapp_template_id'] = $templateId;
    $insertApiLog['whatsapp_api_status_id'] = $apiStatusId;
    $insertApiLog['whatsapp_lead_id'] = $lead_id;
    $insertApiLog['whatsapp_user_id'] = $user_id;
    $insertApiLog['whatsapp_errors'] = $errorMessage;
    $insertApiLog['whatsapp_created_on'] = date("Y-m-d H:i:s");

    //$leadModelObj->insertTable("api_whatsapp_logs", $insertApiLog);

    $response_array['status'] = $apiStatusId;
    $response_array['mobile'] = $mobile;
    $response_array['errors'] = $errorMessage;

    if ($debug == 1) {
        $response_array['request_json'] = $json_request;
        $response_array['response_json'] = $apiResponseJson;
    }
    return $response_array;
}

?>
